<?php
/**
 *	@package	Imgur
 *	@version 	3.0
 *	@author 	Cim 
 *	@link 		https://github.com/demyxco/elgg
 */
 
return array(
	'imgur:clientid' => 'Client ID',
	'imgur:link' => 'Please get your key here: <a href="https://api.imgur.com/oauth2/addclient" target="_blank">Imgur Key</a>',
);