<?php
/**
 *	@package	Blog Cover Photo
 *	@version 	3.0
 *	@author 	Cim 
 *	@link 		https://github.com/demyxco/elgg
 */
 
return array(
	'blogcoverphoto:covermessage' => 'Drag image here for cover photo',
	'blogcoverphoto:delete' => 'Delete Cover',
);