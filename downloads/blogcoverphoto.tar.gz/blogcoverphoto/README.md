# Blog Cover Photo
Simple blog cover photo plugin

### FEATURES
* Drag and drop
* Ajax upload
* Responsive

### Metadata
KEY | VALUE
------------- | -------------
blogcoverphoto_url | NULL

### LINKS
* Elgg Repository: https://elgg.org/plugins/1552344