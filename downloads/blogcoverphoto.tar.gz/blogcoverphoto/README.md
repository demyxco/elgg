# Blog Cover Photo
Simple blog cover photo plugin

### Features
* Drag and drop
* Ajax upload
* Responsive

### Metadata
KEY | VALUE
------------- | -------------
blogcoverphoto_url | NULL

### Links
* Elgg Repository: https://elgg.org/plugins/1552344