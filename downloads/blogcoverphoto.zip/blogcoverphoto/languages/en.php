<?php
/**
 *	@package	Blog Cover Photo
 *	@version 	3.0
 *	@author 	Cim 
 *	@link 		https://github.com/demyxco/elgg
 */
 
return array(
	'blogcoverphoto:covermessage' => 'Drag image here for cover photo',
	'blogcoverphoto:delete' => 'Delete Cover',
	'blogcoverphoto:updatenotice' => 'If you are updating from 2.x to 3.x, then please click the update button below. Do not navigate away from this page after clicking. Give it time to process if you have a lot of blog posts',
	'blogcoverphoto:updatebutton' => 'Update',
	'blogcoverphoto:updatedone' => 'Update complete!',
);